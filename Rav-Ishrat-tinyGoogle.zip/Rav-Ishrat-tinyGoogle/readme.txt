This zip file contains the source code, jar files of the project.

We have included a report and data collection file.

In the report we have added the instructions to run the project both for

1) Java based implementation and 
2) Hadoop based implementation