package baseFiles;

public class WCPair {
public String word;
public int count;

public WCPair(String w, int c) {
	word = w;
	count = c;
}
}
